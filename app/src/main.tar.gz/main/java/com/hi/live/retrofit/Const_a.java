package com.hi.live.retrofit;

import com.hi.live.BuildConfig;

public interface Const_a {


    String DEVKEY = "5TIvw5cpc0";
    String PREF_NAME = "userpref";
    String USER = "user";

    String ISLOGIN = "islogin";
    String NOTIFICATION_TOKEN = "fcmtoken";
    String Country = "country";
    String notificationIntent = "notification";
    String CHAT_COUNT = "chatcount";
    String HISTORY = "serchhistory";
    String SETTING = "setting";
    String Is_Guest_Login = "isguest";
    String ADS = "ads";
    int LIMIT = 20;
    String CHAT_CHARGES = "5";
    String IS_FIRST_TIMEHOST = "hostfirsttime";
    String POLICY_ACCEPTED = "policyaccepted";
    String IMAGE_MALE = BuildConfig.BASE_URL + "storage/male.png";
    String IMAGE_FEMALE = BuildConfig.BASE_URL + "storage/fe male.png";
    String Country_CODE = "countrycode";
    String RATES = "rates";
    String EMAIL = "waweapp@gmail.com";
    String BANNER = "banner";
    String DownloadBanner = "downloadbanner";
    String CALLDISCONNECT = "callDisconnect";
    String HOSTID = "hostId";
    String HOSTNAME = "hostName";
    String HOSTIMAGE = "hostImage";
    String MAKE_CALL = "makeCall";
    String CALL_DATA = "callData";
    String IS_FROM_RANDOM = "isFromRandom";
    String IS_FROM_LIST = "isFromList";
    String DATA = "data";
    int BOTTOM_TO_UP = 1;
    int UP_TO_BOTTOM = 2;
    String IS_PRIVATE = "isPrivate";
}
