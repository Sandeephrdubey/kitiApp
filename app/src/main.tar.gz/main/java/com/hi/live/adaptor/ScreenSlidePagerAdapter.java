package com.hi.live.adaptor;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;

import com.hi.live.fregment.MessageFregment_a;
import com.hi.live.fregment.ProfileFregment_g;
import com.hi.live.fregment.VideoFregment_a;
import com.hi.live.fregment.VideoOfflineFragment_a;

public class ScreenSlidePagerAdapter extends FragmentStateAdapter {
    public ScreenSlidePagerAdapter(FragmentActivity fa) {
        super(fa);
    }

    @Override
    public Fragment createFragment(int position) {
        if (position == 0) {
            return new VideoFregment_a();
        } else if (position == 1) {
            return new VideoOfflineFragment_a();
        } else if (position == 2) {
            return new MessageFregment_a();
        } else {
            return new ProfileFregment_g();
        }
    }

    @Override
    public int getItemCount() {
        return 4;
    }
}