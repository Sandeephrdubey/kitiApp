package com.hi.live.socket;

public interface ChatHandler {

    void onChat(Object[] args);

}
